package main

import (
	"net/http"
)

func main() {
	http.Handle("/", http.FileServer(http.Dir("/home/gl")))
	http.ListenAndServe(":8888", nil)
}

